# -*- coding: utf-8 -*-

from . import crm_lead
from . import calendar
from . import contacts
from . import agreement
from . import hr_employee
from . import project
from . import project_task
from . import feedback
from . import profile
from . import public_holiday
from . import invoice

# -*- coding: utf-8 -*-

from odoo import api, fields, models, _
from datetime import date, timedelta, datetime
import datetime


class TimesheetInvoice(models.Model):
    _name = "timesheet.invoice"
    _inherits = {'account.analytic.account': "analytic_account_id"}

    analytic_account_id = fields.Many2one('account.analytic.account', string='Client Name',
        ondelete="cascade", required=True, auto_join=True)
    invoicing_type_id = fields.Many2one('job.invoicing', string="Invoicing Type")
    invoice_start_date = fields.Date(string="Start Date")
    invoice_end_date = fields.Date(string="End Date")
    hour_selection = fields.Selection([('10','10 Hours'),('20','20 Hours'),('30','30 Hours'),
                                       ('40','40 Hours'),('80','80 Hours'),('90','90 Hours'),
                                       ('100','100 Hours'),('40_20','40-20 Hours'),
                                       ('20_10','20-10 Hours'),('160','160 Hours'),
                                       ('180','180 Hours'),('200','200 Hours')], string="Working Hours")
    rate_per_hour = fields.Float(string="Rate Per Hour")
    min_bill = fields.Float('Min. Bill')
    worked_hours = fields.Float('Worked Hours')
    ideal_hours = fields.Float('Ideal Hours')
    hours_charged = fields.Float('Hours Charged')
    bill_amount = fields.Float('Bill Amount')
    disc_amount = fields.Float('Disc. Amount')
    final_amount = fields.Float('Final Amount')
    holidays = fields.Float('Holidays')
    billed = fields.Boolean(string="Billed")
    cancelled = fields.Boolean(string="Cancelled")

    @api.onchange('bill_amount','disc_amount')
    def _onchange_final_amount(self):
        self.final_amount = self.bill_amount - self.disc_amount
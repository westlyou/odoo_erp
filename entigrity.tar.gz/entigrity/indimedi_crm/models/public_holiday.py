from odoo import api, fields, models
from datetime import datetime
from dateutil.relativedelta import relativedelta

import time


class PublicHoliday(models.Model):
    _name = 'public.holiday'

    name = fields.Char(string='Holiday Name')
    public_holiday_date = fields.Date(string='Date')